# Piper starter (darwin/amd64)

Ready-to-run folder for one migration on **darwin/amd64**. The binary is in
this directory — no global PATH install required.

```bash
./piper doctor
./piper inspect
./piper plan --target mongo
./piper execute
./piper validate
```

## Setup

1. Copy `env.example` → `.env` and fill in `PIPER_SOURCE_URL` / `PIPER_TARGET_URL`.
2. Load the env into your shell (see comments in `env.example`).
3. Run the commands above from **this folder root**.

## Other platforms

Need a different OS/CPU? Download the matching starter zip or binary from the
landing page `downloads/` and `starter/` folders.

## Optional: global install

```bash
# macOS / Linux
sudo cp ./piper /usr/local/bin/piper
```

Windows: add this folder to your user PATH, or copy `piper.exe` somewhere already on PATH.

## Folders

| Path | Purpose |
|------|---------|
| `notes/` | Your review notes and cutover checklist |
| `scripts/` | Optional helpers you add |
| `.piper/` | Created automatically by inspect/plan/execute |

Same-dialect migrations are out of scope. Pick a different dialect for `--target`.
