# Scripts

Empty on purpose. Add optional shell helpers for this migration. Piper itself
is at the starter root (`./piper` or `.\piper.exe`) — no global install needed.
